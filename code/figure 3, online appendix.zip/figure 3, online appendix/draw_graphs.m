filename='20180404T155110.mat';
load(filename);

a=cell2mat(results(:,5));
c=cell2mat(results(:,2));
delta=cell2mat(results(:,4));

results_n = ~cellfun(@isempty,results);
eff_and_stb=cell2mat(results(results_n(:,8)==1,8));

two_star=strncmp(results(results_n(:,9)==1,9),{'2-Star'},6);
three_star=strncmp(results(results_n(:,9)==1,9),{'3-Star'},6);
all_paired=strncmp(results(results_n(:,9)==1,9),{'2-Complete'},6);
empty=strncmp(results(results_n(:,9)==1,9),{'Empty Environment'},6);
GC=strncmp(results(results_n(:,9)==1,9),{'Grand Club Environment'},6);

% for all graphs/a's, add the all paired environments for c=0:
a_vec=unique(a);
for i=1:size(a_vec)
    delta_vec=unique(delta(a==a_vec(i),1));
    % add a values:
    add_a=ones(size(delta_vec,1),1);
    add_a=add_a*a_vec(i);
    a=vertcat(a,add_a);
    % add c values:
    add_zeros=zeros(size(delta_vec,1),1);
    c=vertcat(c,add_zeros);
    % add delta values:
    add_delta=delta_vec;
    delta=vertcat(delta,add_delta);
    % add eff_and_stable values:
    add_ones=ones(size(delta_vec,1),1);
    eff_and_stb=vertcat(eff_and_stb,add_ones);
    % add environment type flags:
    two_star=vertcat(two_star,add_zeros);
    three_star=vertcat(three_star,add_zeros);
    empty=vertcat(empty,add_zeros);
    GC=vertcat(GC,add_zeros);
    all_paired=vertcat(all_paired,add_ones); 
end

% check if the types of environment we defined covers all environments the algorithm bumped into:
temp=[two_star three_star all_paired empty GC];
if sum(temp(:))==size(a,1)
    types_are_exhaustive=1;
    disp('all types of environments are covered');
end


for i=1:size(a_vec)
    
    hold off
    
    % eff and stb, non 2-star\3-star\all-paired\empty\GC (blue circle):
    cond=(a==a_vec(i) & eff_and_stb==1 & two_star==0 & three_star==0 ...
        & all_paired==0 & empty==0 & GC==0);
    scatter(c(cond,:),delta(cond,:),[],'blue','o');
    hold on
    
    % non eff and stb, non 2-star\3-star\all-paired\empty\GC (red circle):
    cond=(a==a_vec(i) & eff_and_stb==0 & two_star==0 & three_star==0 ...
        & all_paired==0 & empty==0 & GC==0);
    scatter(c(cond,:),delta(cond,:),[],'red','o');
    
    % eff and stb, 2 star (blue plus):
    cond=(a==a_vec(i) & eff_and_stb==1 & two_star==1);
    scatter(c(cond,:),delta(cond,:)...
        ,[],'blue','+');
    hold on
    
    % non eff and stb, 2 star (red plus):
    cond=(a==a_vec(i) & eff_and_stb==0 & two_star==1);
    scatter(c(cond,:),delta(cond,:),[],'red','+');
    hold on
    
    % eff and stb, 3 star (blue asterisk):
    cond=(a==a_vec(i) & eff_and_stb==1 & three_star==1);
    scatter(c(cond,:),delta(cond,:),[],'blue','*');
    hold on
    
    % non eff and stb, 3 star (red asterisk):
    cond=(a==a_vec(i) & eff_and_stb==0 & three_star==1);
    scatter(c(cond,:),delta(cond,:),[],'red','*');
    hold on
    
    % eff and stb, all paired (blue point):
    cond=(a==a_vec(i) & eff_and_stb==1 & all_paired==1);
    scatter(c(cond,:),delta(cond,:),[],'blue','.');
    hold on
    
    % non eff and stb, all paired (red point):
    cond=(a==a_vec(i) & eff_and_stb==0 & all_paired==1);
    scatter(c(cond,:),delta(cond,:),[],'red','.');
    hold on
    
    % eff and stb, empty (blue cross):
    cond=(a==a_vec(i) & eff_and_stb==1 & empty==1);
    scatter(c(cond,:),delta(cond,:),[],'blue','x');
    hold on
    
    % non eff and stb, empty (red cross):
    cond=(a==a_vec(i) & eff_and_stb==0 & empty==1);
    scatter(c(cond,:),delta(cond,:),[],'red','x');
    hold on
    
    % eff and stb, GC (blue square):
    cond=(a==a_vec(i) & eff_and_stb==1 & GC==1);
    scatter(c(cond,:),delta(cond,:),[],'blue','s');
    hold on
    
    % non eff and stb, GC (red square):
    cond=(a==a_vec(i) & eff_and_stb==0 & GC==1);
    scatter(c(cond,:),delta(cond,:),[],'red','s');
    
    %make the graph nice:
    xlim([-0.3 3.3])
    ylim([0 1])
    title(['efficiency vs stability, a=',num2str(a_vec(i))])
    xlabel('cost') % x-axis label
    ylabel('delta') % y-axis label
    %legend('effi env is stable','effi env is not stable','Location','northwest')
    saveas(gcf,['a=',num2str(a_vec(i)),', 5agents.png']);

end

%% export coordinates to use later in latex:

for i=1:size(a_vec)
    % 2-star stable
    cond=(a==a_vec(i) & eff_and_stb==1 & two_star==1);
    two_star_stb=[c(cond,:),delta(cond,:)];
    filename=['a=',num2str(a_vec(i)),'_two_star_stb','.dat'];
    dlmwrite(filename,two_star_stb,'\t')
    
    % 2-star unstable
    cond=(a==a_vec(i) & eff_and_stb==0 & two_star==1);
    two_star_unstb=[c(cond,:),delta(cond,:)];
    filename=['a=',num2str(a_vec(i)),'_two_star_unstb','.dat'];
    dlmwrite(filename,two_star_unstb,'\t')
    
    % 3-star stable
    cond=(a==a_vec(i) & eff_and_stb==1 & three_star==1);
    three_star_stb=[c(cond,:),delta(cond,:)];
    filename=['a=',num2str(a_vec(i)),'_three_star_stb','.dat'];
    dlmwrite(filename,three_star_stb,'\t')
    
    % 3-star unstable
    cond=(a==a_vec(i) & eff_and_stb==0 & three_star==1);
    three_star_unstb=[c(cond,:),delta(cond,:)];
    filename=['a=',num2str(a_vec(i)),'_three_star_unstb','.dat'];
    dlmwrite(filename,three_star_unstb,'\t')
    
    % all paired stable
    cond=(a==a_vec(i) & eff_and_stb==1 & all_paired==1);
    all_paired_stb=[c(cond,:),delta(cond,:)];
    filename=['a=',num2str(a_vec(i)),'_all_paired_stb','.dat'];
    dlmwrite(filename,all_paired_stb,'\t')
    
    % all paired unstable
    cond=(a==a_vec(i) & eff_and_stb==0 & all_paired==1);
    all_paired_unstb=[c(cond,:),delta(cond,:)];
    filename=['a=',num2str(a_vec(i)),'_all_paired_unstb','.dat'];
    dlmwrite(filename,all_paired_unstb,'\t')
    
    % empty stable
    cond=(a==a_vec(i) & eff_and_stb==1 & empty==1);
    empty_stb=[c(cond,:),delta(cond,:)];
    filename=['a=',num2str(a_vec(i)),'_empty_stb','.dat'];
    dlmwrite(filename,empty_stb,'\t')
    
    % empty unstable
    cond=(a==a_vec(i) & eff_and_stb==0 & empty==1);
    empty_unstb=[c(cond,:),delta(cond,:)];
    filename=['a=',num2str(a_vec(i)),'_empty_unstb','.dat'];
    dlmwrite(filename,empty_unstb,'\t')
    
    % GC stable
    cond=(a==a_vec(i) & eff_and_stb==1 & GC==1);
    GC_stb=[c(cond,:),delta(cond,:)];
    filename=['a=',num2str(a_vec(i)),'_GC_stb','.dat'];
    dlmwrite(filename,GC_stb,'\t')
    
    % GC unstable
    cond=(a==a_vec(i) & eff_and_stb==0 & GC==1);
    GC_unstb=[c(cond,:),delta(cond,:)];
    filename=['a=',num2str(a_vec(i)),'_GC_unstb','.dat'];
    dlmwrite(filename,GC_unstb,'\t')
    
end