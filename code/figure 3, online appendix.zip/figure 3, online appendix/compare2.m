%% choose how dense to make the grid:
%density=10;

%% default config:
club_membership_cost=NaN;
club_congestion_function='exponential'; %may be 'exponential','inv','none','zeros','one','constant','fix',''.
club_congestion_delta=NaN;
club_congestion_a=NaN;
individual_congestion_function='none';
individual_congestion_delta=NaN;
individual_congestion_a=NaN;
geodesic_distance=NaN;
number_of_agents=5;
number_of_clubs=NaN;
input_file_name=NaN;
clubwise_stability='open';
processing_type='';
max_number_of_generations=1000;
target_folder='';

%% run exhaustive and efficiency tests:
row_count=1;
point_num=1;

results=cell(1700,9); %to store results, the table may grow bigger...

jump_a=0.05; %0.25;
jump_c=0.3; %1.5;
jump_delta=0.05; %0.4;

a=0;
while a<=0.5
    delta=0+jump_delta;
    while delta>0 && delta<1 && a+delta<1
        c=0+jump_c;
        while c>0 && c<=3
            club_congestion_a=a;
            club_congestion_delta=delta;
            club_membership_cost=c;
    
            % insert parameters into "config":
            Model=struct('club_membership_cost',club_membership_cost,'club_congestion_function'...
                ,club_congestion_function,'club_congestion_delta',club_congestion_delta...
                ,'club_congestion_a',club_congestion_a,'individual_congestion_function',individual_congestion_function...
                ,'individual_congestion_delta',individual_congestion_delta,'individual_congestion_a',individual_congestion_a...
                ,'geodesic_distance',geodesic_distance);
            Environment=struct('number_of_agents',number_of_agents,'number_of_clubs',number_of_clubs...
                ,'input_file_name',input_file_name);
            Processing=struct('clubwise_stability',clubwise_stability,'processing_type',processing_type...
                ,'max_number_of_generations',max_number_of_generations...
                ,'target_folder',target_folder);
            config=struct('Model',Model,'Environment',Environment,'Processing',Processing);
    
            %submit to exhaustive analysis and retrieve a list of all strongly efficient environments:
            addpath(genpath('C:\Users\User\Dropbox\Chaim\Final\Code\New\Code\Code 1.8'))
            runExEffi(config)
            rmpath('C:\Users\User\Dropbox\Chaim\Final\Code\New\Code\Code 1.8')
    
            %check stability of the SE environments found:
            global EffiCell
            for j=1:max(size(EffiCell))
                addpath(genpath('C:\Users\User\Dropbox\Chaim\Final\Code\New\Code\Code 1.8'))
                [stability,~]=AnalyzeConfig(config,EffiCell{j});
                rmpath('C:\Users\User\Dropbox\Chaim\Final\Code\New\Code\Code 1.8')
                %get the environment's tag:
                addpath(genpath('C:\Users\User\Dropbox\Chaim\Final\Code\New\Code\Code 1.8'))
                tag=tagMemMap(EffiCell{j});
                rmpath('C:\Users\User\Dropbox\Chaim\Final\Code\New\Code\Code 1.8')
                
                %store results:
                results(row_count,1)={point_num};
                results(row_count,2)={club_membership_cost};
                results(row_count,3)={club_congestion_function};
                results(row_count,4)={club_congestion_delta};
                results(row_count,5)={club_congestion_a};
                results(row_count,6)={number_of_agents};
                results(row_count,7)={EffiCell};
                results(row_count,8)={stability};
                results(row_count,9)={tag};
                
                disp(results(row_count,:));
                
                row_count=row_count+1;
            end
            point_num=point_num+1;
            
            c=c+jump_c;
        end
        delta=delta+jump_delta;
    end
    %save workspace:
    filename=datestr(now,30);
    save(filename)
    
    a=a+jump_a;
end
%% save workspace:
filename=datestr(now,30);
save(filename)

%% plot results:
% a_0=results(1:100,:);
% c=cell2mat(a_0(:,2));
% delta=cell2mat(a_0(:,4));
% eff_and_stb=cell2mat(a_0(:,8));
% scatter(c(eff_and_stb==1,:),delta(eff_and_stb==1,:),[],'blue','o');
% hold on
% scatter(c(eff_and_stb==0,:),delta(eff_and_stb==0,:),[],'red','x');
% title('efficiency and stability')
% xlabel('cost') % x-axis label
% ylabel('delta') % y-axis label
% legend('effi env is stable','effi env is not stable','Location','northwest')
% saveas(gcf,'5agents, a=0','png')
% hold off