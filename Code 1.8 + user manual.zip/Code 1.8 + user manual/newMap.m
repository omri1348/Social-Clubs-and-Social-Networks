function map = newMap(maxNumClubs,nAgents,allClubs)
% creates a new environment
    if isempty(allClubs)
        map = createMapOld(maxNumClubs, nAgents);
    else
        map = createMap(maxNumClubs, nAgents, allClubs);
    end
end