function vec = string2vector(s)
    vec = zeros(1,length(s));
    for i = 1:length(s)
        if (strcmp(s(i),'1'))
            vec(i) = 1;
        end    
    end        
end