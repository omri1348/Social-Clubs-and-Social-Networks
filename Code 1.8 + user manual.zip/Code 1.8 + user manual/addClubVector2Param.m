function param = addClubVector2Param(config,param)
    if (strcmp(config.Model.club_congestion_function,'fix'))
        param{4,4} = 'club_fixVector';
        for i = 2:length(config.Model.club_fix_vector)
            param{4,3+i} = config.Model.club_fix_vector(i);
            param{3,3+i} = [num2str(i) ' Agents'];
        end
    end    
end