function efficiency2(filePath)
%% Description:
% run efficiency test with source file
    warning('off','MATLAB:xlswrite:AddSheet')
    config = demoConfig();
    config.Environment.input_filename = filePath;
    [targetFolder,~,ext] = fileparts(filePath);
    if(~strcmp(ext,'.xlsx'))
        error('Invalid file');
    end   
    config.Processing.target_folder = targetFolder;
    config = readExcelEnvironment(config, filePath);
    if (config.Environment.number_of_agents <= 5)
        runExEffi(config) 
    else
        runGenEffi(config)
    end   
end
