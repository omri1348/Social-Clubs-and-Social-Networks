function a = one(m)
a = 1;
end
