function allClubs = createAllIthClubs(nAgents, i)
%% Description:
% create the matrix of all clubs with i agents out of nAgents

allCombo = nchoosek(1:nAgents, i)';
numOfclubs = size(allCombo,2);
linSpace = linspace(0, nAgents*(numOfclubs - 1), numOfclubs);
allCombo = allCombo + linSpace;  
allClubs = zeros(nAgents, numOfclubs);
allClubs(allCombo) = true;
end
